请先填写相关配置：在Config.properties里
client_ID ：appkey                           
client_SERCRET ：app_secret
redirect_URI : 回调地址